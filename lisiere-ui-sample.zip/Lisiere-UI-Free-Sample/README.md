# Lisière UI — Free sample

Created with generative AI: artwork, code and documentation. Commercial finished-project use allowed under LICENSE.txt; standalone redistribution of the source or assets is not.

## Try the actual Godot source

Install the free standard Godot 4.6.1 editor, extract this entire ZIP, then Import godot/project.godot and press F5. This sample has six slots, three item types, stack limits, quantities, whole-stack drag/move/merge/swap, selection details, add/reset and the Sage theme. It makes no network calls. Requires basic Godot/GDScript knowledge to integrate or modify.

Test it on your target system before purchasing. Development checks used Godot 4.6.1 Linux. Other engine versions/platforms, touch/gamepad and web persistence are not certified.

The paid Inventory Starter adds the satchel/chest example with one/all transfer buttons, local save/load, eight demo items, three palettes, editable Theme resources, minimal integration and garden delivery scenes, an offline web companion, EN/FR guides, source tests and the original full art collection. No equipment/crafting, multiplayer or custom integration is included.

## Graphics-only sample

The sage/ folder retains 8 icon designs and 4 UI variants: 12 SVG files and 36 transparent PNGs at 1×/2×/4×. These are separate from the three icons in the Godot demo.

## Français

Extraire tout le ZIP. Dans Godot 4.6.1, importer godot/project.godot puis lancer F5. Glisser les objets pour les déplacer, fusionner les piles ou échanger deux objets différents. Tabulation + Entrée pour sélectionner. Cet échantillon n'a ni coffre ni sauvegarde. Les fichiers sont utilisables dans vos projets finis selon LICENSE.txt. Visuels, code et documentation générés avec une IA.

https://lisiere-ui.onrender.com/
